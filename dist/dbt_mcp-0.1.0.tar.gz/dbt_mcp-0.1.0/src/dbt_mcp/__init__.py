def main() -> None:
    print("Coming soon!")
